
ELITE PLAYER CV WEBSITE

BESTANDEN:
index.html (landing page)
builder.html (CV generator)

ONLINE ZETTEN:

1. Ga naar GitHub
2. Maak repository: elite-player-cv
3. Upload beide bestanden
4. Ga naar Settings → Pages
5. Deploy from branch

Je website staat dan live.

Later kun je Stripe toevoegen om eerst te laten betalen voordat iemand PDF downloadt.
